package WorkingAbstraction.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW,
}
