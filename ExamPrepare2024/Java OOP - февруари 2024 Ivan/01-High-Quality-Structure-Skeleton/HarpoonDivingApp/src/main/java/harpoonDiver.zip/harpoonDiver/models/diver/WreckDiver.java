package harpoonDiver.models.diver;

public class WreckDiver extends BaseDiver{
    private static  final double WRECK_DIVER = 150;


    public WreckDiver(String name) {
        super(name, WRECK_DIVER);
    }
}
