package harpoonDiver.models.seaCatch;

import java.util.Collection;

//Морски улов
public interface SeaCatch {
    Collection<String> getSeaCreatures();
}
