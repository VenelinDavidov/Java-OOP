package harpoonDiver.models.divingSite;

import java.util.Collection;
//Място за гмуркане

public interface DivingSite {

    Collection<String> getSeaCreatures();

    String getName();
}
