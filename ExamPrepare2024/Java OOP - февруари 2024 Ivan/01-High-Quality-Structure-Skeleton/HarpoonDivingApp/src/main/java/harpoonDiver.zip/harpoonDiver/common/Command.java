package harpoonDiver.common;

public enum Command {
    AddDiver,
    AddDivingSite,
    RemoveDiver,
    StartDiving,
    GetStatistics,
    Exit,
}
