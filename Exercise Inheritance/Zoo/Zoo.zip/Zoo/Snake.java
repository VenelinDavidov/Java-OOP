package Zoo;

public class Snake extends Reptile{
    // name;
    public Snake(String name) {
        super(name);
    }
}
