package Zoo;

public class Bear extends Mammal{
    // name
    public Bear(String name) {
        super(name);
    }
}
