package Zoo;

public class Reptile extends  Animal{

    // name
    public Reptile(String name) {
        super(name);
    }
}
