package Zoo;

public class Lizard extends Reptile{
    // name;
    public Lizard(String name) {
        super(name);
    }
}
