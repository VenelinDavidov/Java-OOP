package Person01;

public class Child extends Person {   //Person-> super class
    // name , age fields
    public Child(String name, int age) {
        super(name, age);
        // constructor Person
    }
}
